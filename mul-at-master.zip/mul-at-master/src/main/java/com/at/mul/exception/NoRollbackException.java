package com.at.mul.exception;

public class NoRollbackException extends Exception {

	private static final long serialVersionUID = 341192781956845817L;

}
