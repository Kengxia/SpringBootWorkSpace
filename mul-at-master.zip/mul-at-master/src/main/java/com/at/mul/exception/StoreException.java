package com.at.mul.exception;

public class StoreException extends Exception {

	private static final long serialVersionUID = 341192781956845817L;

}
